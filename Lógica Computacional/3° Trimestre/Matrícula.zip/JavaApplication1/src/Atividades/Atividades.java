
package Atividades;

import javax.swing.JOptionPane;

public class Atividades {

    public static void main(String[] args) {
        algoritmo () ;
        informações ();
        carro();
        
    }
    public static void informações () {
       String nome= JOptionPane.showInputDialog(null,"Digite seu nome abaixo. ");
       String idade= JOptionPane.showInputDialog(null,"Digite sua idade abaixo. ");
       String address= JOptionPane.showInputDialog(null,"Digite seu endereço abaixo. ");
       JOptionPane.showInputDialog(null,"Estes são seus dados.\n " + nome + "\n" + idade + "\n" + address);
       
    }
    public static void carro() {
        long distancia = Long.parseLong (JOptionPane.showInputDialog(null, "Digite a distancia em quilometros. ")) ;
        long consumo = Long.parseLong  (JOptionPane.showInputDialog(null, "Digite a quilemetragem que seu carro faz por lito. ")) ;
        double gasolina = Double.parseDouble (JOptionPane.showInputDialog(null, "Digite o preço da gasolina. ")) ;
        double formula = (double) distancia / consumo *gasolina;
        JOptionPane.showMessageDialog (null,"Valor da viagem " + formula + "reais") ;
       }    
    public static void algoritmo (){
        double n1 = Double.parseDouble (JOptionPane.showInputDialog("insira o primeiro numero"));
        double n2 = Double.parseDouble (JOptionPane.showInputDialog("insira o segundo numero"));
        double n3 = Double.parseDouble (JOptionPane.showInputDialog("insira o terceiro numero"));
        double n4 = Double.parseDouble (JOptionPane.showInputDialog("insira o quarto numero"));
        double potencia1 = n1*n1;
        double potencia2 = n2*n2;
        double potencia3 = n3*n3;
        double potencia4 = n4*n4;
        if (potencia3 >= 1000) {
        JOptionPane.showMessageDialog(null, "O quadrado de " + n3 + "resultou em " + potencia3 +".");
        } else {
         JOptionPane.showMessageDialog(null, "O quadrado dos numeros inseridos são respectivamente:\n" + n1 + potencia1 + "e" + n2 + potencia2 + "e" + n3 + potencia3 + "e" + n4 + potencia4);
        }
        }
  public static void par() {
       int n = Integer.parseInt(JOptionPane.showInputDialog("Digite um numero inteiro."));
       if (n % 2 == 0) { 
           JOptionPane.showMessageDialog(null, "O numero digitado é par");
       } else { JOptionPane.showMessageDialog(null, "O numero digitado não é par"); }
       if (n > 0) {
           JOptionPane.showMessageDialog(null, "Seu numero é positivo");
       } else if(n == 0){
           JOptionPane.showMessageDialog(null, "Seu numero é nulo");
       }else {
           JOptionPane.showMessageDialog(null, "Seu numero é negativo");
       }
  }
}
       




    
    
